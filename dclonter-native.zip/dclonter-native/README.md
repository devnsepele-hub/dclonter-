# dClonter Native
**Developer:** devnsepele | **Version:** 1.0.0

Clone app sungguhan pakai Android Native (Java) + GitHub Actions build.

## Cara Push ke GitHub (dari Termux)

```bash
# Clone repo dulu di GitHub (buat repo baru: dclonter-native)
# Lalu di Termux:

git init
git remote add origin https://github.com/devnsepele-hub/dclonter-native.git
git add .
git commit -m "init: dClonter Native v1.0.0"
git push -u origin main
```

Setelah push → GitHub Actions otomatis build → download APK di tab **Artifacts**.

## Yang Sudah Fungsional
- ✅ Baca list app terinstall (PackageManager)
- ✅ Clone APK ke private directory
- ✅ Install clone via PackageInstaller API
- ✅ Launch clone app
- ✅ Delete clone
- ✅ Fingerprint spoof profile (IMEI, Android ID, MAC, Serial)
- ✅ Random package name untuk setiap clone

## Yang Butuh Tambahan (Next Step)
- LSPosed module untuk hook TelephonyManager (spoof IMEI aktif)
- Magisk + PlayIntegrityFix untuk bypass SafetyNet
- Frida gadget untuk anti-VM detection di dalam clone
