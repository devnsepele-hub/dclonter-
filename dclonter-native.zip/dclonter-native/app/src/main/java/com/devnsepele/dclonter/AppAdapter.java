package com.devnsepele.dclonter;

import android.content.Context;
import android.content.pm.*;
import android.graphics.drawable.Drawable;
import android.view.*;
import android.widget.*;
import java.util.List;

public class AppAdapter extends BaseAdapter {

    Context ctx;
    List<ApplicationInfo> apps;
    PackageManager pm;

    public AppAdapter(Context ctx, List<ApplicationInfo> apps) {
        this.ctx  = ctx;
        this.apps = apps;
        this.pm   = ctx.getPackageManager();
    }

    @Override public int getCount()              { return apps.size(); }
    @Override public Object getItem(int i)       { return apps.get(i); }
    @Override public long getItemId(int i)       { return i; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(ctx)
                .inflate(R.layout.item_app, parent, false);
        }

        ApplicationInfo app = apps.get(position);

        ImageView icon   = convertView.findViewById(R.id.appIcon);
        TextView  name   = convertView.findViewById(R.id.appName);
        TextView  pkg    = convertView.findViewById(R.id.appPkg);
        Button    btnClone = convertView.findViewById(R.id.btnClone);

        Drawable d = app.loadIcon(pm);
        icon.setImageDrawable(d);
        name.setText(app.loadLabel(pm));
        pkg.setText(app.packageName);

        // Check apakah sudah di-clone
        List<String> cloned = VirtualSpaceManager.getInstance(ctx).getClonedPackages();
        boolean isCloned = cloned.contains(app.packageName);

        if (isCloned) {
            btnClone.setText("Launch ▶");
            btnClone.setBackgroundColor(0xFF30D158);
            btnClone.setOnClickListener(v ->
                VirtualSpaceManager.getInstance(ctx).launchClone(app.packageName)
            );
        } else {
            btnClone.setText("Clone ⧉");
            btnClone.setBackgroundColor(0xFF0A84FF);
            btnClone.setOnClickListener(v -> {
                VirtualSpaceManager.getInstance(ctx).cloneApp(app.packageName);
                Toast.makeText(ctx, "Cloning " + app.loadLabel(pm) + "...",
                    Toast.LENGTH_SHORT).show();
                notifyDataSetChanged();
            });
        }

        return convertView;
    }
}
