package com.devnsepele.dclonter;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.*;
import android.view.*;
import android.graphics.drawable.Drawable;
import java.util.List;
import java.util.ArrayList;

public class MainActivity extends Activity {

    ListView listView;
    AppAdapter adapter;
    List<ApplicationInfo> installedApps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);

        loadInstalledApps();

        adapter = new AppAdapter(this, installedApps);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            ApplicationInfo app = installedApps.get(position);
            VirtualSpaceManager.getInstance(this).cloneApp(app.packageName);
            Toast.makeText(this,
                "Cloning: " + app.packageName,
                Toast.LENGTH_SHORT).show();
        });
    }

    void loadInstalledApps() {
        PackageManager pm = getPackageManager();
        installedApps = new ArrayList<>();
        List<ApplicationInfo> all = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        for (ApplicationInfo info : all) {
            // Filter hanya user-installed apps
            if ((info.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                installedApps.add(info);
            }
        }
    }
}
