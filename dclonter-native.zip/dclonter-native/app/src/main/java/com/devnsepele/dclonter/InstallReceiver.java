package com.devnsepele.dclonter;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.util.Log;
import android.widget.Toast;

public class InstallReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS,
                                        PackageInstaller.STATUS_FAILURE);
        String pkg = intent.getStringExtra(PackageInstaller.EXTRA_PACKAGE_NAME);

        switch (status) {
            case PackageInstaller.STATUS_SUCCESS:
                Toast.makeText(ctx, "✓ Clone berhasil diinstall: " + pkg,
                    Toast.LENGTH_LONG).show();
                Log.d("InstallReceiver", "Install sukses: " + pkg);
                break;
            case PackageInstaller.STATUS_PENDING_USER_ACTION:
                // Minta konfirmasi user
                Intent confirm = (Intent) intent.getParcelableExtra(Intent.EXTRA_INTENT);
                if (confirm != null) {
                    confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    ctx.startActivity(confirm);
                }
                break;
            default:
                String msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
                Toast.makeText(ctx, "✗ Install gagal: " + msg, Toast.LENGTH_LONG).show();
                Log.e("InstallReceiver", "Install gagal: " + msg);
        }
    }
}
