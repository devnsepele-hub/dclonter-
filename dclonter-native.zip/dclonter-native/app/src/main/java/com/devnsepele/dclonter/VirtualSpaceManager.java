package com.devnsepele.dclonter;

import android.content.Context;
import android.content.Intent;
import android.content.pm.*;
import android.os.*;
import android.util.Log;
import java.io.*;
import java.util.*;

/**
 * VirtualSpaceManager
 * Core engine untuk clone dan launch app di virtual space.
 *
 * Cara kerja:
 * 1. Copy APK dari storage ke private dir kita
 * 2. Rewrite package name jadi clone unik
 * 3. Install ke user profile kedua (Android multi-user API)
 * 4. Launch via UserHandle
 *
 * Tidak butuh root — pakai Android Work Profile API (DevicePolicyManager)
 * atau secondary user (UserManager) yang tersedia di Android 5+
 */
public class VirtualSpaceManager {

    private static final String TAG = "VirtualSpaceManager";
    private static VirtualSpaceManager instance;
    private final Context ctx;

    // Direktori private untuk simpan APK clone
    private final File cloneDir;

    // Map package asli → package clone
    private final Map<String, String> cloneRegistry = new HashMap<>();

    private VirtualSpaceManager(Context context) {
        this.ctx = context.getApplicationContext();
        this.cloneDir = new File(ctx.getFilesDir(), "clones");
        if (!cloneDir.exists()) cloneDir.mkdirs();
        loadRegistry();
    }

    public static synchronized VirtualSpaceManager getInstance(Context ctx) {
        if (instance == null) instance = new VirtualSpaceManager(ctx);
        return instance;
    }

    // ── CLONE APP ────────────────────────────────────────────────────────────
    public void cloneApp(String packageName) {
        new Thread(() -> {
            try {
                // 1. Cari APK source
                PackageManager pm = ctx.getPackageManager();
                ApplicationInfo info = pm.getApplicationInfo(packageName, 0);
                String apkPath = info.sourceDir;

                // 2. Generate clone package name unik
                String clonePkg = "com.devnsepele.clone." + randomHex(6) + "." +
                                  packageName.replace(".", "_");

                // 3. Copy APK ke private dir
                File dest = new File(cloneDir, clonePkg + ".apk");
                copyFile(new File(apkPath), dest);

                // 4. Rewrite manifest package name (butuh ApkTool / binaryXML edit)
                // Di sini kita pakai pendekatan sederhana:
                // Launch di secondary Android user agar package name tidak conflict
                rewriteAndInstall(dest, packageName, clonePkg);

                // 5. Simpan registry
                cloneRegistry.put(packageName, clonePkg);
                saveRegistry();

                Log.d(TAG, "Clone berhasil: " + packageName + " → " + clonePkg);

            } catch (Exception e) {
                Log.e(TAG, "Clone gagal: " + e.getMessage());
            }
        }).start();
    }

    // ── LAUNCH CLONE ─────────────────────────────────────────────────────────
    public void launchClone(String originalPkg) {
        String clonePkg = cloneRegistry.get(originalPkg);
        if (clonePkg == null) {
            Log.e(TAG, "Clone tidak ditemukan untuk: " + originalPkg);
            return;
        }
        try {
            PackageManager pm = ctx.getPackageManager();
            Intent intent = pm.getLaunchIntentForPackage(clonePkg);
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(intent);
            }
        } catch (Exception e) {
            Log.e(TAG, "Launch gagal: " + e.getMessage());
        }
    }

    // ── DELETE CLONE ─────────────────────────────────────────────────────────
    public void removeClone(String originalPkg) {
        String clonePkg = cloneRegistry.remove(originalPkg);
        if (clonePkg != null) {
            // Uninstall via Intent (user confirm)
            Intent intent = new Intent(Intent.ACTION_DELETE);
            intent.setData(android.net.Uri.parse("package:" + clonePkg));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(intent);
            saveRegistry();
        }
    }

    // ── REWRITE & INSTALL ────────────────────────────────────────────────────
    private void rewriteAndInstall(File apk, String origPkg, String clonePkg) {
        /**
         * Full binary XML rewrite butuh library:
         *   implementation 'com.github.iBotPeaches:Apktool:2.9.3'
         *
         * Untuk sekarang: install APK asli ke secondary user
         * Secondary user punya namespace terpisah — package name sama tidak konflik
         *
         * Cara install ke secondary user:
         *   adb shell pm install --user [userId] [apk]
         *   Atau via PackageInstaller API (Android 5+)
         */
        installViaPackageInstaller(apk);
    }

    private void installViaPackageInstaller(File apk) {
        try {
            PackageInstaller installer = ctx.getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(
                PackageInstaller.SessionParams.MODE_FULL_INSTALL
            );
            int sessionId = installer.createSession(params);
            PackageInstaller.Session session = installer.openSession(sessionId);

            // Write APK ke session
            try (OutputStream out = session.openWrite("clone.apk", 0, apk.length());
                 InputStream in = new FileInputStream(apk)) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                session.fsync(out);
            }

            // Commit install
            android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(
                ctx, sessionId,
                new Intent("com.devnsepele.dclonter.INSTALL_STATUS"),
                android.app.PendingIntent.FLAG_UPDATE_CURRENT |
                android.app.PendingIntent.FLAG_IMMUTABLE
            );
            session.commit(pi.getIntentSender());
            session.close();

        } catch (Exception e) {
            Log.e(TAG, "Install gagal: " + e.getMessage());
        }
    }

    // ── FINGERPRINT SPOOF ────────────────────────────────────────────────────
    /**
     * Spoof fingerprint untuk app di dalam clone.
     * Butuh hook via:
     *   - LSPosed module (recommended, no root jika pakai Work Profile)
     *   - Frida gadget inject ke proses clone
     *
     * Target hook:
     *   android.telephony.TelephonyManager → getImei(), getDeviceId()
     *   android.provider.Settings.Secure   → ANDROID_ID
     *   android.os.Build                   → SERIAL, FINGERPRINT, MODEL
     *   java.net.NetworkInterface          → getHardwareAddress() [MAC]
     */
    public void applySpoofProfile(SpoofProfile profile) {
        // Simpan profile ke SharedPreferences
        // LSPosed module kita akan baca dari sini saat hook dipanggil
        ctx.getSharedPreferences("spoof", Context.MODE_PRIVATE)
            .edit()
            .putString("imei",      profile.imei)
            .putString("androidId", profile.androidId)
            .putString("mac",       profile.mac)
            .putString("serial",    profile.serial)
            .putString("model",     profile.model)
            .apply();
        Log.d(TAG, "Spoof profile diterapkan: " + profile.model);
    }

    // ── UTILITY ──────────────────────────────────────────────────────────────
    private void copyFile(File src, File dst) throws IOException {
        try (InputStream in = new FileInputStream(src);
             OutputStream out = new FileOutputStream(dst)) {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    private String randomHex(int len) {
        StringBuilder sb = new StringBuilder();
        Random rnd = new Random();
        String chars = "abcdef0123456789";
        for (int i = 0; i < len; i++)
            sb.append(chars.charAt(rnd.nextInt(chars.length())));
        return sb.toString();
    }

    private void saveRegistry() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : cloneRegistry.entrySet())
            sb.append(e.getKey()).append("=").append(e.getValue()).append("\n");
        try {
            File f = new File(ctx.getFilesDir(), "clone_registry.txt");
            FileWriter fw = new FileWriter(f);
            fw.write(sb.toString());
            fw.close();
        } catch (IOException e) {
            Log.e(TAG, "Save registry gagal");
        }
    }

    private void loadRegistry() {
        try {
            File f = new File(ctx.getFilesDir(), "clone_registry.txt");
            if (!f.exists()) return;
            BufferedReader br = new BufferedReader(new FileReader(f));
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("=", 2);
                if (parts.length == 2) cloneRegistry.put(parts[0], parts[1]);
            }
            br.close();
        } catch (IOException e) {
            Log.e(TAG, "Load registry gagal");
        }
    }

    public List<String> getClonedPackages() {
        return new ArrayList<>(cloneRegistry.keySet());
    }

    // ── SPOOF PROFILE MODEL ───────────────────────────────────────────────────
    public static class SpoofProfile {
        public String imei, androidId, mac, serial, model, brand;
        public SpoofProfile() {
            // Default random-ish values
            this.imei      = "35" + randomDigits(13);
            this.androidId = randomHex8();
            this.mac       = "AC:37:43:" + randomMac();
            this.serial    = "RF8N" + randomHex8().toUpperCase();
            this.model     = "SM-G991B";
            this.brand     = "samsung";
        }
        private static String randomDigits(int n) {
            StringBuilder sb = new StringBuilder();
            Random r = new Random();
            for (int i = 0; i < n; i++) sb.append(r.nextInt(10));
            return sb.toString();
        }
        private static String randomHex8() {
            return Long.toHexString(new Random().nextLong() & 0xFFFFFFFFL);
        }
        private static String randomMac() {
            Random r = new Random();
            return String.format("%02X:%02X:%02X", r.nextInt(256), r.nextInt(256), r.nextInt(256));
        }
    }
}
